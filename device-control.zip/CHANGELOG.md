## Version: 1.0.0

    * initial working version of the panel
