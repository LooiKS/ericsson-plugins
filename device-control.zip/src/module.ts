import { MetricsPanelCtrl } from 'grafana/app/plugins/sdk';
import defaultsDeep from 'lodash/defaultsDeep';
import { AppEvents, DataFrame } from '@grafana/data';
import $ from 'jquery';
import mqtt, { MqttClient, IClientOptions } from 'mqtt';
import './style.css';
import angluar from 'angular';
import config from 'grafana/app/core/config';
import { UtilSrv } from 'app/core/services/util_srv';
import { appEvents } from 'grafana/app/core/core';
import { backendSrv } from 'app/core/services/backend_srv';

interface KeyValue {
  key: string;
  value: any;
}

export default class MqttCtrl extends MetricsPanelCtrl {
  static templateUrl = 'partials/module.html';

  panelDefaults = {
    // Value
    value: 10,
    //Server
    mqttProtocol: 'ws',
    // mqttServer: '192.168.178.47', //TODO: get base url from website
    mqttServerPort: 9001,
    mqttTopicSubscribe: 'grafana/mqtt-panel',
    mqttTopicPublish: 'grafana/mqtt-panel/set',
    mqttAuth: 'None',
    mqttUser: '',
    mqttPassword: '',
    // GUI
    mode: 'Text',
    // Text
    text: 'Send',
    // Slider
    minValue: 0,
    maxValue: 100,
    step: 1,
    // Switch //TODO: Translate
    offValue: 'false',
    onValue: 'true',
  };

  client: mqtt.MqttClient;
  input: any = null;
  value: any = null;

  devices: [] = [];
  originalDevices: [] = [];
  deviceSelected = {};
  bulkFrequency: number = 0;
  bulkEnabled: boolean = false;
  connectClass = 'failed';
  newNodeInput = {
    id: null,
    desc: null,
    name: null,
    password: null,
    frequency: null,
    createdBy: null,
    isEnabled: null,
  };
  isLoading = { true: true };

  search = '';

  // Simple example showing the last value of all data
  firstValues: KeyValue[] = [];

  /** @ngInject */
  constructor($scope, $injector, public templateSrv, private utilSrv: UtilSrv, private $http: any) {
    super($scope, $injector);
    defaultsDeep(this.panel, this.panelDefaults);

    // Get results directly as DataFrames
    (this as any).dataFormat = 'series';

    this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
    this.events.on('render', this.onRender.bind(this));
    this.events.on('data-error', this.onDataError.bind(this));

    angluar.module('grafana.directives').directive('stringToNumber', this.stringToNumber);
    this.fetchDevice();
  }

  fetchDevice() {
    this.deviceSelected = [];
    this.$http.get(this.panel.endpointUrl + '/device-control/get-all-devices').then(resp => {
      resp.data.forEach(device => {
        device.isEnabled = device.isEnabled === 'Y';
      });
      this.devices = resp.data;
      this.originalDevices = resp.data;
    });
  }

  onInitEditMode() {
    this.addEditorTab('Server', `public/plugins/${this.pluginId}/partials/options.server.html`, 3);
  }

  onRender() {
    if (!this.firstValues || !this.firstValues.length) {
      return;
    }

    // Tells the screen capture system that you finished
    this.renderingCompleted();
  }

  onDataError(err: any) {
    console.log('onDataError', err);
  }

  // 6.3+ get typed DataFrame directly
  handleDataFrame(data: DataFrame[]) {
    const values: KeyValue[] = [];

    for (const frame of data) {
      for (let i = 0; i < frame.fields.length; i++) {
        values.push({
          key: frame.fields[i].name,
          value: frame.fields[i].values,
        });
      }
    }

    this.firstValues = values;
  }

  link(scope: any, elem: any, attrs: any, ctrl: any) {
    this.input = $(elem.find('#value')[0]);
    console.log('link');
  }

  stringToNumber() {
    return {
      require: 'ngModel',
      link: function(scope, element, attrs, ngModel) {
        ngModel.$parsers.push(function(value) {
          return '' + value;
        });
        ngModel.$formatters.push(function(value) {
          return parseFloat(value);
        });
      },
    };
  }

  saveBulkEnabled() {
    var devices = [];
    for (var key of Object.keys(this.deviceSelected)) {
      if (this.deviceSelected[key]) {
        devices.push(key);
      }
    }

    if (devices.length) {
      this.utilSrv.showConfirmModal({
        title: 'Confirmation',
        text: 'Confirm to update devices: ' + devices + '?',
        onConfirm: () => {
          this.$http({
            url: this.panel.endpointUrl + '/device-control/update-bulk-enabled',
            method: 'POST',
            data: {
              ids: devices,
              isEnabled: this.bulkEnabled ? 'Y' : 'N',
              updateBy: config.bootData.user.id.toString(),
            },
          }).then(jsonResp => {
            if (jsonResp.status === 'failed') {
              appEvents.emit(AppEvents.alertSuccess, [jsonResp.error]);
            } else {
              appEvents.emit(AppEvents.alertSuccess, ['Node updated']);
              this.fetchDevice();
            }
          });
        },
      });
    }
  }

  saveBulkFrequency() {
    var devices = [];
    for (var key of Object.keys(this.deviceSelected)) {
      if (this.deviceSelected[key]) {
        devices.push(key);
      }
    }

    if (devices.length) {
      this.utilSrv.showConfirmModal({
        title: 'Confirmation',
        text: 'Confirm to update frequency of devices: ' + devices + '?',
        onConfirm: () => {
          this.$http({
            url: this.panel.endpointUrl + '/device-control/update-bulk-frequency',
            method: 'POST',
            data: {
              ids: devices,
              frequency: this.bulkFrequency,
              updateBy: config.bootData.user.id.toString(),
            },
          }).then(jsonResp => {
            if (jsonResp.status === 'failed') {
              appEvents.emit(AppEvents.alertSuccess, [jsonResp.error]);
            } else {
              appEvents.emit(AppEvents.alertSuccess, ['Node(s) updated']);
              this.fetchDevice();
            }
          });
        },
      });
    }
  }

  updateDevice({ id, frequency, isEnabled, desc, name }) {
    this.utilSrv.showConfirmModal({
      title: 'Confirmation',
      text: 'Confirm to update device: ' + id + '?',
      onConfirm: () => {
        this.$http({
          url: this.panel.endpointUrl + '/device-control/update-device',
          method: 'POST',
          params: {
            id,
            desc,
            name,
            frequency,
            isEnabled: isEnabled ? 'Y' : 'N',
            updateBy: config.bootData.user.id.toString(),
          },
        }).then(resp => {
          if (resp.status === 'failed') {
            appEvents.emit(AppEvents.alertError, [resp.error]);
          } else {
            appEvents.emit(AppEvents.alertSuccess, ['Node updated']);
            this.fetchDevice();
          }
        });
      },
    });
  }

  deleteDevice({ id, frequency, isEnabled, desc, name }) {
    this.utilSrv.showConfirmModal({
      title: 'Confirmation',
      text: 'Confirm to delete device: ' + id + '? This action is not reversible!',
      onConfirm: () => {
        this.$http({
          url: this.panel.endpointUrl + '/device-control/delete-device',
          method: 'POST',
          params: {
            id,
          },
        }).then(resp => {
          if (resp.status === 'failed') {
            appEvents.emit(AppEvents.alertError, [resp.error]);
          } else {
            appEvents.emit(AppEvents.alertSuccess, ['Node deleted']);
            this.fetchDevice();
          }
        });
      },
    });
  }
  resetData({ id }) {
    var input = {
      from: new Date(),
      to: new Date(),
    };
    this.utilSrv.showModal({
      src: `public/plugins/${this.pluginId}/partials/reset_confirm.html`,
      modalClass: 'confirm-modal',
      model: {
        id: id,
        input,
        title: 'Confirmation',
        onConfirm: () => {
          this.utilSrv.showConfirmModal({
            title: 'Confirmation',
            text: `Confirm to delete data of ${id} from ${input.from.toLocaleString()} to ${input.to.toLocaleString()}?`,
            onConfirm: () => {
              this.$http({
                url: this.panel.endpointUrl + '/device-control/delete-device-data',
                method: 'POST',
                params: {
                  id,
                  from: input.from.getTime(),
                  to: input.to.getTime(),
                },
              }).then(resp => {
                var data = resp.data;
                if (data.status === 'failed') {
                  appEvents.emit(AppEvents.alertError, [data.error]);
                } else {
                  appEvents.emit(AppEvents.alertSuccess, [`${data.num} node data deleted.`]);
                }
              });
            },
          });
          console.log(input);
        },
      },
    });
  }

  addNode(form) {
    if (form.$valid) {
      this.utilSrv.showConfirmModal({
        title: 'Confirmation',
        text: 'Confirm to add new node?',
        onConfirm: () => {
          fetch(this.panel.endpointUrl + '/device-control/create-device', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({
              id: this.newNodeInput.id,
              desc: this.newNodeInput.desc,
              name: this.newNodeInput.name,
              password: this.newNodeInput.password,
              frequency: this.newNodeInput.frequency,
              createdBy: config.bootData.user.id.toString(),
              isEnabled: this.newNodeInput.isEnabled ? 'Y' : 'N',
            }),
          })
            .then(response => response.json())
            .then(jsonResp => {
              if (jsonResp.status === 'failed') {
                appEvents.emit(AppEvents.alertError, [jsonResp.error]);
              } else {
                appEvents.emit(AppEvents.alertSuccess, ['Node added']);
                this.fetchDevice();
                form.$setPristine();
                this.newNodeInput = {
                  createdBy: null,
                  isEnabled: null,
                  desc: null,
                  frequency: null,
                  id: null,
                  name: null,
                  password: null,
                };
              }
            });
        },
      });
    }
  }

  searchDevices() {
    this.devices = this.originalDevices.filter(device => {
      if (device)
        for (var key of Object.keys(device)) {
          if (
            device[key] &&
            device[key]
              .toString()
              .toUpperCase()
              .indexOf(this.search.toUpperCase()) !== -1
          )
            return device;
        }
    });
  }

  isTesting = false;
  test() {
    if (this.panel.endpointUrl) {
      this.isTesting = true;
      this.$http
        .get(this.panel.endpointUrl + '/device-control/get-all-devices', {
          headers: { 'content-type': 'application/json' },
        })
        .then(resp => {
          this.connectClass = resp.status === 200 ? 'successful' : 'failed';
        })
        .catch(reason => {
          this.connectClass = 'failed';
        })
        .finally(() => {
          this.isTesting = false;
        });
    }
  }
}

export { MqttCtrl as PanelCtrl };
